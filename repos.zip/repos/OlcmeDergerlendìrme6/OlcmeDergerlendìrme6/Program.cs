﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OlcmeDergerlendırme6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                Televizyon tv = new Televizyon();
                tv.KanalDegistir(20);
                System.Console.WriteLine(tv.KanalNo);
                tv.KanalNoArtir();
                System.Console.WriteLine(tv.KanalNo);
                tv.KanalNoArtir(5);
                System.Console.WriteLine(tv.KanalNo);
                tv.KanalNoAzalt();
                System.Console.WriteLine(tv.KanalNo);
                tv.KanalNoAzalt(3);
                System.Console.WriteLine(tv.KanalNo);
            }
        }
    }
    class Televizyon
    {
        public int SesSeviyesi { get; set; }
        public double EkranBoyutu { get; set; }
        public string GoruntuTeknolojisi
        {
            get; set;
        }
        bool gucAcik = false;
        int kanalNo = 1;
        public int KanalNo
        {
            get { return kanalNo; }
        }
        public void GucAc()
        {
            gucAcik = true;
        }
        public void GucKapat()
        {
            gucAcik = false;
        }
        public void KanalDegistir(int kanalNo)
        {
            this.kanalNo = kanalNo;
        }
        public void KanalNoArtir()
        {
            kanalNo++;
        }
        public void KanalNoArtir(int artis)
        {
            kanalNo += artis;
        }
        public void KanalNoAzalt()
        {
            kanalNo--;
        }
        public void KanalNoAzalt(int azalis)
        {
            kanalNo -= azalis;
        }
        public int SesSeviyesiOku()
        {
            return SesSeviyesi;
        }
    }
}
