﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OlcmeDegerlındırme
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Televizyon tv = new Televizyon();
            tv.KanalDegistir(20);
            System.Console.WriteLine(tv);
            tv.KanalNoArtir(10);
            System.Console.WriteLine(tv);
          
            tv.KanalNoAzalt(3);
            System.Console.WriteLine(tv);
        }

    


        class Televizyon
        {
            public int SesSeviyesi { get; set; }

            public double EkranBoyutu { get; set; }

            public string GoruntuTeknolojisi { get; set; }

            bool gucAcik = false;
            int kanalNo = 1;
            public void GucAc()
            {
                gucAcik = true;
            }
            public void GucKapat()
            {
                gucAcik = false;
            }
            public void KanalDegistir(int kanalNo)
            {
                this.kanalNo = kanalNo;

            }
            public int SesSeviyesiOku()
            {
                return SesSeviyesi;
            }
            public void KanalNoArtir()
            {
                kanalNo++;
            }
            public void KanalNoArtir(int artis)
            {
                kanalNo += artis;
            }
            public void KanalNoAzalt()
            {
                kanalNo--;
            }
            public void KanalNoAzalt(int azalis)
            {
                kanalNo -= azalis;
            }
            
        
        }
    }
}