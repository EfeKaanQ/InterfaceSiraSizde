﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoyutKutuphane
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Kitap kitap = new Kitap();
            kitap.Oku();
            Dergi dergi = new Dergi();
            dergi.Oku();
            Ansiklopedi ansiklopedi = new Ansiklopedi();
            ansiklopedi.Oku();

        }
    }
    public abstract class Ortak
    {
        public uint SayfaSayisi { get; set; }
        public string Adı { get; set; }
        public int YayinYili { get; set; }

        public abstract void Oku();
        
         
        
    }

    public class Kitap : Ortak
    {
        public uint Turu { get; set; }

        public override void Oku()
        {
            Console.WriteLine("Kitap okuma işlemi tamamlandı.");
        }
    }

    public class Dergi : Ortak
    {

        public string Konu { get; set; }

        public override void Oku()
        {
            Console.WriteLine("dergi okuma işlemi tamam");

        }
    }
    public class Ansiklopedi : Ortak
    {
        public string Ogretici { get; set; }

        public override void Oku()
        {
            Console.WriteLine("Ansiklopedi okuma tamam ");
        }

    }
}
