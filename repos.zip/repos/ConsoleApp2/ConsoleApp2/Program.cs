﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WindowHeight = 16;
            Console.WindowWidth = 32;
            int screenwidth = Console.WindowWidth;
            int screenheight = Console.WindowHeight;
            Random randomnummer = new Random();
            bool isGameOn = true;

            pixel hoofd = new pixel();
            hoofd.xpos = screenwidth / 2;
            hoofd.ypos = screenheight / 2;
            hoofd.schermkleur = ConsoleColor.Cyan;
            string hoofdstring = "*";
            int score = 0;

            pixel eten = new pixel();
            eten.xpos = randomnummer.Next(1, screenwidth);
            eten.ypos = randomnummer.Next(1, screenheight);
            eten.schermkleur = ConsoleColor.Green;

            List<int> xposlijf = new List<int>();
            List<int> yposlijf = new List<int>();
            int lijflengte = 5;
            string lijfKarakter = "*";

            pixel obstakel = new pixel();
            obstakel.schermkleur = ConsoleColor.Red;
            obstakel.xpos = randomnummer.Next(1, screenwidth);
            obstakel.ypos = randomnummer.Next(1, screenheight);

            DateTime tijdwaarneming = DateTime.Now;
            string buttonpressed = "no";
            while (isGameOn)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("SNAKE GAME");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Score:" + score);
                Console.SetCursorPosition(hoofd.xpos, hoofd.ypos);
                Console.ForegroundColor = hoofd.schermkleur;
                Console.Write(hoofdstring);
                Console.SetCursorPosition(eten.xpos, eten.ypos);
                Console.ForegroundColor = eten.schermkleur;
                Console.Write("*");

                Console.SetCursorPosition(obstakel.xpos, obstakel.ypos);
                Console.ForegroundColor = obstakel.schermkleur;
                Console.Write("O");

                for (int i = 0; i < xposlijf.Count(); i++)
                {
                    Console.SetCursorPosition(xposlijf[i], yposlijf[i]);
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write(lijfKarakter);
                }

                Console.ForegroundColor = ConsoleColor.White;
                Console.BackgroundColor = ConsoleColor.Black;
                Console.SetCursorPosition(screenwidth - 1, screenheight - 1);
                Console.Write("@");

                ConsoleKeyInfo info = Console.ReadKey();
                // input wordt opgeslagen in de variable buttonpressed
                // hierdoor wordt de richting bepaald

                // controle op welke knop is ingedrukt
                switch (info.Key)
                {
                    case ConsoleKey.UpArrow:
                        buttonpressed = "up";
                        break;
                    case ConsoleKey.DownArrow:
                        buttonpressed = "down";
                        break;
                    case ConsoleKey.LeftArrow:
                        buttonpressed = "left";
                        break;
                    case ConsoleKey.RightArrow:
                        buttonpressed = "right";
                        break;
                }

                // op basis van welke knop is ingedrukt wordt de richting bepaald
                switch (buttonpressed)
                {
                    case "up":
                        hoofd.ypos--;
                        break;
                    case "down":
                        hoofd.ypos++;
                        break;
                    case "left":
                        hoofd.xpos--;
                        break;
                    case "right":
                        hoofd.xpos++;
                        break;
                }

                // het hoofd van de slang wordt toegevoegd aan het lichaam d.m.v. xpos en ypos
                xposlijf.Insert(0, hoofd.xpos);
                yposlijf.Insert(0, hoofd.ypos);

                // controle of het hoofd van de slang een eten raakt
                if (hoofd.xpos == eten.xpos && hoofd.ypos == eten.ypos)
                {
                    score++;
                    eten.xpos = randomnummer.Next(1, screenwidth);
                    eten.ypos = randomnummer.Next(1, screenheight);
                }
                else
                {
                    xposlijf.RemoveAt(xposlijf.Count - 1);
                    yposlijf.RemoveAt(yposlijf.Count - 1);
                }

                // controle of het hoofd van de slang een obstakel raakt
                if (hoofd.xpos == obstakel.xpos && hoofd.ypos == obstakel.ypos)
                {
                    isGameOn = false;
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME OVER!");
                    Console.WriteLine("Je hebt een obstakel geraakt!");
                }

                // controle of het hoofd van de slang de randen raakt
                if (hoofd.xpos < 0 || hoofd.xpos >= screenwidth || hoofd.ypos < 0 || hoofd.ypos >= screenheight)
                {
                    isGameOn = false;
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME OVER!");
                    Console.WriteLine("Je hebt de muur geraakt!");
                }

                // controle of het hoofd van de slang zichzelf raakt
                for (int i = 0; i < xposlijf.Count - 1; i++)
                {
                    if (hoofd.xpos == xposlijf[i] && hoofd.ypos == yposlijf[i])
                    {
                        isGameOn = false;
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("GAME OVER!");
                        Console.WriteLine("Je hebt jezelf geraakt!");
                    }
                }

                Thread.Sleep(100);
            }
        }
    }

    class pixel
    {
        public int xpos { get; set; }
        public int ypos { get; set; }
        public ConsoleColor schermkleur { get; set; }
    }
}
    

