﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sirasizde1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                Console.Write("Dairenin yarıçapını girin: ");
                double yaricap = Convert.ToDouble(Console.ReadLine());

                Daire daire1 = new Daire(yaricap);
                double alan = daire1.AlanHesapla();

                Console.WriteLine("Dairenin alanı: " + alan);

                Console.ReadLine();
            }
        }
    }
}
    class Daire
    {
        private double yaricap;

        
        public Daire(double yaricap)
        {
            this.yaricap = yaricap;
        }

        
        public double AlanHesapla()
        {
            return Math.PI * Math.Pow(yaricap, 2);
        }
    }



        
         
        
     