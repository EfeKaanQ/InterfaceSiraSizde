﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DaireMetod
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double yaricap;

            do
            {
                Console.Write("Dairenin yarıçapını girin: ");
            } while (!double.TryParse(Console.ReadLine(), out yaricap));

            Daire daire1 = new Daire(yaricap);
            double alan = daire1.AlanHesapla();

            Console.WriteLine("Dairenin alanı: " + alan);

            Console.ReadLine();
        }
    }
}
    class Daire
    {


        private double yaricap;



        public Daire(double yaricap)
    {
        this.yaricap = yaricap;
    }

  
    public double AlanHesapla()
    {
        return Math.PI * Math.Pow(yaricap, 2);
    }
}